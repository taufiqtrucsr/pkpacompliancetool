function InvalidCharachter(type, testField)
{
	switch(type)
	{
		case 'text' : 
				var invalidChars = '0123456789`~!@#$%^&*()[]\{\}\-_+=/\'\\"<>,.;:?^|';
				for (i=0; i<invalidChars.length; i++) {
					if (testField.indexOf(invalidChars.charAt(i),0) > -1)
					{
						return false;			
					}
				}
				break;
		case 'number' :
				var invalidNumbers = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz`~!@#$%^&*()[]\{\}\-_=/\'\\"<>,.;:?^|';
				for (i=0; i<invalidNumbers.length; i++) {
					if (testField.indexOf(invalidNumbers.charAt(i),0) > -1)
					{
						return false;			
					}
				}
				break;
		default : 
				return false;
				break;
	}
}


function IsNumeric(strString)
{
	var strValidChars = "0123456789";
	var strChar;
	var blnResult = true;

	if (strString.length == 0) return false;

	for (i = 0; i < strString.length && blnResult == true; i++)
	  {
	  strChar = strString.charAt(i);
	  if (strValidChars.indexOf(strChar) == -1)
		 {
		 blnResult = false;
		 }
	  }
	return blnResult;
}


/**************** Validate Admin user ******************************/
function validateuser()
{
	
	var first_name			= document.getElementById("first_name").value;
	var last_name			= document.getElementById("last_name").value;
	var username			= document.getElementById("user_name").value;
	var password			= document.getElementById("password").value;
	var confirm_password	= document.getElementById("confirm_password").value;
	var email_id			= document.getElementById("email_id").value;

	var error			= document.getElementById('error');
	var regMail		= /^([_a-zA-Z0-9-]+)(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,3})$/;

	var errorMsg = '';
	document.getElementById('error').style.display = 'block';

	
	if(first_name == "")
	{
		errorMsg += "Please enter first name";
		document.getElementById("first_name").focus();
		
	}
	else if(last_name == "")
	{
		errorMsg += "Please enter Lastname";
		document.getElementById("last_name").focus();
		
	}
	else if(username == "")
	{
		errorMsg += "Please enter username";
		document.getElementById("user_name").focus();
		
	}
	else if(password == "")
	{
		errorMsg += "Please enter password";
		document.getElementById("password").focus();
		
	}
	else if(confirm_password == "")
	{
		errorMsg += "Please enter Confirm password ";
		document.getElementById("confirm_password").focus();
		
	}
	else if(confirm_password != "" && password != confirm_password)
	{
		errorMsg += "Please enter password and Confirm password must be same";
		document.getElementById("confirm_password").focus();
		
	}
	else if(email_id == "")
	{
		errorMsg += "Please enter valid Email";
		document.getElementById("email_id").focus();
		
	}
	else if(!regMail.test(email_id) && email_id != '' ){
		errorMsg += 'Please enter valid Email ID.'; 
		document.getElementById('email_id').focus();
	}

	if(errorMsg != '')
	{
		error.innerHTML = errorMsg;
		return false;
	}
		
	return true;
	
}


/************************ Validate customer **********************************/

function validate_customer()
{
	
	var first_name			= document.getElementById("first_name").value;
	var lastname			= document.getElementById("last_name").value;
	
	var email_id			= document.getElementById("email_id").value;
	var phone				= document.getElementById("phone").value;

	var error				= document.getElementById('error');
	var regMail				= /^([_a-zA-Z0-9-]+)(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,3})$/;

	var errorMsg = '';
	document.getElementById('error').style.display = 'block';


	
	if(first_name == "")
	{
		errorMsg += "Please enter first name";
		document.getElementById("first_name").focus();
		
	}
	else if(lastname == "")
	{
		errorMsg += "Please enter Lastname";
		document.getElementById("last_name").focus();
		
	}
	else if(email_id == "")
	{
		errorMsg += "Please enter valid Email";
		document.getElementById("email_id").focus();
		
	}
	else if(!regMail.test(email_id) && email_id != '' ){
		errorMsg += 'Please enter valid Email ID.'; 
		document.getElementById('email_id').focus();
	}

	
	else if(phone == "")
	{
		errorMsg += "Please enter valid phone number ";
		document.getElementById("phone").focus();
		
	}
	
	if(errorMsg != ''){
		error.innerHTML = errorMsg;
		return false;
	}
		
	return true;
	
}


/************************ Validate Buyer **********************************/

function validate_buyer()
{
	
	var first_name			= document.getElementById("first_name").value;
	var lastname			= document.getElementById("last_name").value;
	var username			= document.getElementById("username").value;
	var password			= document.getElementById("password").value;
	var confirm_password	= document.getElementById("confirm_password").value;
	var email_id			= document.getElementById("email_id").value;
	var phone				= document.getElementById("phone").value;
	var website_url			= document.getElementById("website_url").value;

	var error			= document.getElementById('error');
	var regMail		= /^([_a-zA-Z0-9-]+)(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,3})$/;

	var errorMsg = '';
	document.getElementById('error').style.display = 'block';

	if(first_name == "")
	{
		errorMsg += "Please enter first name";
		document.getElementById("first_name").focus();
		
	}
	else if(lastname == "")
	{
		errorMsg += "Please enter Lastname";
		document.getElementById("last_name").focus();
		
	}
	else if(email_id == "")
	{
		errorMsg += "Please enter valid Email";
		document.getElementById("email_id").focus();
		
	}
	else if(!regMail.test(email_id) && email_id != '' ){
		errorMsg += 'Please enter valid Email ID.'; 
		document.getElementById('email_id').focus();
	}

	else if(username == "")
	{
		errorMsg += "Please enter username";
		document.getElementById("username").focus();
		
	}
	else if(password == "")
	{
		errorMsg += "Please enter password";
		document.getElementById("password").focus();
		
	}
	else if(confirm_password == "")
	{
		errorMsg += "Please enter Confirm password ";
		document.getElementById("confirm_password").focus();
		
	}
	else if(phone == "")
	{
		errorMsg += "Please enter valid phone number ";
		document.getElementById("phone").focus();
		
	}
	else if(website_url == "")
	{
		errorMsg += "Please enter valid website url ";
		document.getElementById("website_url").focus();
		
	}

	if(errorMsg != ''){
		error.innerHTML = errorMsg;
		return false;
	}
		

	
}

/************************* Validate category*************************************/

function validate_category()
{
	var category_name		= document.getElementById("category_name").value;

	var error			= document.getElementById('error');
	var regMail		= /^([_a-zA-Z0-9-]+)(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,3})$/;

	var errorMsg = '';
	document.getElementById('error').style.display = 'block';


	if(category_name == "")
	{
		errorMsg += "Please enter category name.";
		document.getElementById("category_name").focus();
		
	}

	if(errorMsg != ''){
		error.innerHTML = errorMsg;
		return false;
	}
		
	return true;
	
}



/******** Add Product Validaton ******** Start *******************/

function ValidateProduct()
{
	var P_Name			= document.getElementById("name").value;
	var P_Cat			= document.getElementById("category").value;
	var P_Desc			= document.getElementById("message").value;
	var P_MetaTitle		= document.getElementById("meta_title").value;
	var P_MetaKeyword	= document.getElementById("meta_keyword").value;
	var P_MetaDesc		= document.getElementById("meta_description").value;
	var P_MainSku		= document.getElementById("main_sku").value;
	var P_Image1		= document.getElementById("image1").value;
	var p_qty			= document.getElementById("p_qty").value;
	var unit_price		= document.getElementById("unit_price").value;

	var error			= document.getElementById('error');
	var regMail		= /^([_a-zA-Z0-9-]+)(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,3})$/;

	var errorMsg = '';
	document.getElementById('error').style.display = 'block';


	if(P_Name == "")
	{
		errorMsg +=  "Please enater product name";
		document.getElementById("name").focus();
	}
	else if(P_Cat == "")
	{
		errorMsg += "Please select category";
		document.getElementById("category").focus();
	}
	else if(P_Desc == "")
	{
		errorMsg += "Please enter description";
		document.getElementById("message").focus();
	}
	else if(P_MetaTitle == "")
	{
		errorMsg +=  "Please enter meta title";
		document.getElementById("meta_title").focus();
		
	}
	else if(P_MetaKeyword == "")
	{
		errorMsg +=  "Please enter meta keyword";
		document.getElementById("meta_keyword").focus();
		
	}
	else if(P_MetaDesc == "")
	{
		errorMsg += "Please enter meta description";
		document.getElementById("meta_description").focus();
		
	}
	else if(P_MainSku == "")
	{
		errorMsg += "Please enate main sku";
		document.getElementById("main_sku").focus();
		
	}
	else if(P_Image1 == "")
	{
		errorMsg +=  "Please Select image";
		document.getElementById("image1").focus();

	}
	else if(p_qty == "")
	{
		errorMsg += "Please enetr quantity";
		document.getElementById("p_qty").focus();
	
	}
	else if(unit_price == "")
	{
		errorMsg +=  "Please enetr proper unit price";
		document.getElementById("unit_price").focus();
		
	}

	if(errorMsg != ''){
		error.innerHTML = errorMsg;
		return false;
	}
	
	
}

/**************** Validate Banner**********************************/

function validate_banner()
{
	var banner_image		= document.getElementById("hidden_image").value;


	var error			= document.getElementById('error');
	var regMail		= /^([_a-zA-Z0-9-]+)(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,3})$/;

	var errorMsg = '';
	document.getElementById('error').style.display = 'block';


	if(banner_image == "")
	{
		errorMsg += "Please Select proper image.";
		document.getElementById("banner_image").focus();
		
	}

	if(errorMsg != ''){
		error.innerHTML = errorMsg;
		return false;
	}
		
	return true;
	
}

/***************************************************/

function validate_cms()
{
	var P_Name			= document.getElementById("p_name").value;
	var p_title			= document.getElementById("p_title").value;
	var p_meta_title	= document.getElementById("p_meta_title").value;
	var p_meta_keyword	= document.getElementById("p_meta_keyword").value;
	var p_meta_description= document.getElementById("p_meta_description").value;
	var message		    = document.getElementById("message").value;

	var error			= document.getElementById('error');
	var regMail		= /^([_a-zA-Z0-9-]+)(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,3})$/;

	var errorMsg = '';
	document.getElementById('error').style.display = 'block';


	if(P_Name == "")
	{
		errorMsg +=  "Please enater page name";
		document.getElementById("p_name").focus();
	}
	else if(p_title == "")
	{
		errorMsg += "Please select page title";
		document.getElementById("p_title").focus();
	}
	else if(p_meta_title == "")
	{
		errorMsg += "Please enter page meta title";
		document.getElementById("p_meta_title").focus();
	}
	
	else if(p_meta_keyword == "")
	{
		errorMsg +=  "Please enter meta keyword";
		document.getElementById("p_meta_keyword").focus();
		
	}
	else if(p_meta_description == "")
	{
		errorMsg += "Please enter meta description";
		document.getElementById("p_meta_description").focus();
		
	}
	else if(message == "")
	{
		errorMsg += "Please enter description";
		document.getElementById("message").focus();
		
	}


	if(errorMsg != ''){
		error.innerHTML = errorMsg;
		return false;
	}
	
	
}


